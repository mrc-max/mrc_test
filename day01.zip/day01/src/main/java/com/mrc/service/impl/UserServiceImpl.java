package com.mrc.service.impl;

import com.mrc.mapper.UserMapper;
import com.mrc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * UserServiceImpl：
 *
 * @author: 马瑞晨
 * @date: 2019/12/16 16:07
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper usermapper;

    @Override
    public List<Map<String,Object>> selectAllUser()
    {
        return usermapper.selectAllUser();
    }

    @Override
    public int saveuserinfo(String uname, int age) {
        return usermapper.Insertuserinfo(uname,age);
    }
}
