package com.mrc.service;

import java.util.List;
import java.util.Map;

public interface UserService {
    List<Map<String,Object>> selectAllUser();

    int saveuserinfo(String uname,int age);
}
