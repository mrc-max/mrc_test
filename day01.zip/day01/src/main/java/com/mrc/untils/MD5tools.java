package com.mrc.untils;


import java.security.MessageDigest;

/**
 * MD5tools：MD5工具类
 *
 * @author: 马瑞晨
 * @date: 2019/12/17 13:10
 */
public class MD5tools {

    private  static final String[] digital={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"};

    private static String initMD5(String txt) throws Exception {
        //密码
        MessageDigest md5=MessageDigest.getInstance("MD5");
        //digest(byte[]bytes):参数接收文字节数组,返回一个密文数组
        //返回的数组的大小在-256--256之间
        byte[] bytes=md5.digest(txt.getBytes("UTF-8"));
        //创建字符串来存储最终密文
        String miwen="";
        for (byte b:bytes)
        {
            int temp=b;
            if(temp<0)
            {
                temp+=256;
            }
            int i=temp/16;
            int j=temp%16;
            miwen+=digital[i]+digital[j];
        }
        return miwen;
    }
    public  static String finalMD5(String txt) throws Exception {
        return initMD5(initMD5(initMD5(txt)+"taonihouzi"+txt)+"taonihouzi"+txt);
    }
}
