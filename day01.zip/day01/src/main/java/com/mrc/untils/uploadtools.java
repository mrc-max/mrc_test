package com.mrc.untils;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

/**
 * uploadtools：
 *
 * @author: 马瑞晨
 * @date: 2019/12/18 20:50
 */
public class uploadtools {
    public static Map<String,Object> upload01(MultipartFile file,Map<String,Object> map)
    {
        try {
            //获取文件原始名字
            String orgName=file.getOriginalFilename();
            //获取后缀名
            int index=orgName.lastIndexOf(".");
            String ext=orgName.substring(index);
            //获取完整文件名
            String filename= UUID.randomUUID().toString()+ext;
            //获取文件路径以时间的方式命名
            Date d=new Date();
            SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd\\HH\\mm\\ss");
            String dir=sdf.format(d);
            File manydirs=new File("D:\\uploads\\"+dir);
            if (!manydirs.exists())
            {
                manydirs.mkdirs();
            }
            file.transferTo(new File("D:\\uploads\\"+dir+"\\"+filename));
            map.put("imgurl",dir+filename);
            return map;
        } catch (IOException e) {
            e.printStackTrace();
            map.put("status","1");
            return map;
        }
    }
}
