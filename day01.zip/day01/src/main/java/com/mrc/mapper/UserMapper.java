package com.mrc.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface UserMapper {

    @Select("select * from xx")
    List<Map<String,Object>> selectAllUser1();

    List<Map<String,Object>> selectAllUser();

    @Insert("INSERT INTO xx VALUES(null,#{arg0},#{arg1})")
    int Insertuserinfo(String uname,int age);
}
