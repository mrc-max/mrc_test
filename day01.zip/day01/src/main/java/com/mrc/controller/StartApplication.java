package com.mrc.controller;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * StartApplication：
 *
 * @author: 马瑞晨
 * @date: 2019/12/16 13:02
 */

@SpringBootApplication(scanBasePackages = {"com.mrc.controller","com.mrc.service.impl"})
@MapperScan(basePackages="com.mrc.mapper")
public class StartApplication {

    //入口方法
    public static void main(String[] args) {
        //SpringApplicatin是Springboot的启动类
        SpringApplication.run(StartApplication.class);
    }
}
