package com.mrc.controller;


import com.mrc.pojo.QQUser;
import com.mrc.service.UserService;
import com.mrc.untils.uploadtools;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * IndexController：
 *
 * @author: 马瑞晨
 * @date: 2019/12/16 13:38
 */
@Controller
public class IndexController {

    @Autowired
    private UserService userService;

    //测试方法
    @RequestMapping("index.shtml")
    public String index() {

        return "index";
    }

    @RequestMapping("findAlluser.shtml")
    public String findAlluser(Model model) {
        List<Map<String, Object>> userList = userService.selectAllUser();
        model.addAttribute("userList", userList);
        return "index";
    }

    @RequestMapping("adduserinfo.shtml")
    @ResponseBody
    public int adduserinfo(String uname, int age) {

        return userService.saveuserinfo(uname, age);
    }

    @RequestMapping("qqinfo.shtml")
    @ResponseBody
    public boolean qqinfo(@RequestBody QQUser users) {
        System.out.println(users);
        return true;
    }

    /*------------------文件上传---------------------------------*/
    @RequestMapping("upload.shtml")
    @ResponseBody
    public Map<String, Object> upload(@RequestParam(name = "photo") MultipartFile file) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", "0");
        uploadtools.upload01(file, map);
        return map;
    }
}
