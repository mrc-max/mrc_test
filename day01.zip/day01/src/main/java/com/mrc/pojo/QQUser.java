package com.mrc.pojo;


import lombok.*;

import java.io.Serializable;

/**
 * QQUser：
 *
 * @author: 马瑞晨
 * @date: 2019/12/18 14:04
 */
//lombok工具用来生成getset方法等以注解的形式
@Getter
@Setter
@ToString
public class QQUser implements Serializable {
    private String nick;
    private String pwd;
    private String phone;
    private String em;
    private Integer age;
}
